    var dong = new Array();
// 마포구
    dong['공덕동'] = {'x':37.5468700,'y':126.9521720,'trans':5,'food':3,'drink':3,'ent':2,'famous':3,'people':4, 'trail':2,'att':0};
    dong['연남동'] = {'x':37.5638000,'y':126.9223680,'trans':3,'food':5,'drink':3,'ent':1,'famous':5,'people':4, 'trail':5,'att':0};
    dong['서교동'] = {'x':37.5562990,'y':126.9220860,'trans':5,'food':5,'drink':5,'ent':5,'famous':5,'people':5,'trail':2,'att':3};
    dong['대흥동'] = {'x':37.5498980,'y':126.9427770,'trans':3,'food':2,'drink':2,'ent':1,'famous':1,'people':3,'trail':3,'att':0};
    dong['망원동'] = {'x':37.5559770,'y':126.9012820,'trans':1,'food':2,'drink':1,'ent':1,'famous':2,'people':2,'trail':4,'att':0};
    dong['성산동'] = {'x':37.5657430,'y':126.9033060,'trans':2,'food':2,'drink':3,'ent':2,'famous':1,'people':3,'trail':3,'att':2};
    dong['신수동'] = {'x':37.5241240,'y':127.0228830,'trans':3,'food':1,'drink':1,'ent':1,'famous':0,'people':1,'trail':1,'att':0};
    dong['도화동'] = {'x':37.5398010,'y':126.9495110,'trans':2,'food':2,'drink':1,'ent':1,'famous':0,'people':1,'trail':0,'att':0};
    dong['용강동'] = {'x':37.5417870,'y':126.9416680,'trans':2,'food':1,'drink':1,'ent':1,'famous':0,'people':1,'trail':4,'att':0};
    dong['서강동'] = {'x':37.5480090,'y':126.9324190,'trans':3,'food':4,'drink':3,'ent':1,'famous':3,'people':3,'trail':3,'att':0};
    dong['합정동'] = {'x':37.5494250,'y':126.9056720,'trans':1,'food':2,'drink':3,'ent':2,'famous':3,'people':3,'trail':4,'att':0};
    dong['상암동'] = {'x':37.5494250,'y':126.9056720,'trans':2,'food':3,'drink':3,'ent':3,'famous':4,'people':3,'trail':4,'att':3};
// 서대문구
    dong['신촌동'] = {'x':37.5594790,'y':126.9435840,'trans':4,'food':4,'drink':4,'ent':4,'famous':4,'people':4,'trail':1,'att':3};
    dong['연희동'] = {'x':37.5717980,'y':126.9325250,'trans':2,'food':4,'drink':2,'ent':1,'famous':3,'people':3, 'trail':3,'att':0};
    dong['북아현동'] = {'x':37.5609680,'y':126.9542680,'trans':1,'food':1,'drink':1,'ent':1,'famous':1,'people':1,'trail':1,'att':0};
    dong['충현동'] = {'x':37.5628960,'y':126.9623600,'trans':0,'food':1,'drink':1,'ent':1,'famous':0,'people':1,'trail':2,'att':0};
    dong['홍제동'] = {'x':37.5855110,'y':126.9489830,'trans':1,'food':2,'drink':2,'ent':2,'famous':1,'people':1,'trail':2,'att':0};
    dong['홍은동'] = {'x':37.5871320,'y':126.9319760,'trans':0,'food':1,'drink':1,'ent':1,'famous':0,'people':1,'trail':2,'att':0};
    dong['남가좌동'] = {'x':37.5743460,'y':126.9188970,'trans':1,'food':1,'drink':1,'ent':1,'famous':1,'people':1,'trail':1,'att':0};
    dong['북가좌동'] = {'x':37.5784190,'y':126.9099560,'trans':1,'food':2,'drink':2,'ent':2,'famous':1,'people':1,'trail':1,'att':0};
    dong['천연동'] = {'x':37.5710620,'y':126.9590270,'trans':1,'food':2,'drink':3,'ent':2,'famous':3,'people':3,'trail':4,'att':0};
// 중구
    dong['소공동'] = {'x':37.5480090,'y':126.9324190,'trans':3,'food':3,'drink':3,'ent':2,'famous':1,'people':3,'trail':0,'att':0};
    dong['회현동'] = {'x':37.5572300,'y':126.9793300,'trans':3,'food':3,'drink':3,'ent':2,'famous':2,'people':2,'trail':3,'att':2};
    dong['명동'] = {'x':37.5599800,'y':126.9858300,'trans':4,'food':4,'drink':4,'ent':4,'famous':5,'people':5,'trail':2,'att':3};
    dong['필동'] = {'x':37.5600910,'y':126.9955790,'trans':1,'food':2,'drink':2,'ent':1,'famous':1,'people':2,'trail':3,'att':0};
    dong['장충동'] = {'x':37.5617580,'y':127.0077160,'trans':1,'food':2,'drink':3,'ent':2,'famous':2,'people':2,'trail':4,'att':4};
    dong['광희동'] = {'x':37.5644800,'y':127.0052450,'trans':3,'food':3,'drink':3,'ent':2,'famous':4,'people':4,'trail':2,'att':3};
    dong['을지로동'] = {'x':37.5667290,'y':126.9913020,'trans':3,'food':3,'drink':3,'ent':3,'famous':3,'people':3,'trail':2,'att':0};
    dong['신당동'] = {'x':37.5615740,'y':127.0194520,'trans':4,'food':3,'drink':3,'ent':3,'famous':4,'people':3,'trail':2,'att':2};
    dong['다산동'] = {'x':37.554322,'y':127.008476,'trans':2,'food':2,'drink':2,'ent':2,'famous':1,'people':2,'trail':1,'att':0};
    dong['약수동'] = {'x':37.5541020,'y':127.0102520,'trans':2,'food':2,'drink':2,'ent':2,'famous':2,'people':2,'trail':3,'att':1};
    dong['청구동'] = {'x':37.5570834,'y':127.0141305,'trans':2,'food':1,'drink':1,'ent':1,'famous':0,'people':1,'trail':1,'att':0};
    dong['신당5동'] = {'x':37.5650640,'y':127.0218260,'trans':2,'food':2,'drink':2,'ent':2,'famous':2,'people':2,'trail':1,'att':0};
    dong['동화동'] = {'x':37.5601653,'y':127.0187361,'trans':2,'food':1,'drink':1,'ent':1,'famous':1,'people':1,'trail':1,'att':0};
    dong['황학동'] = {'x':37.5674520,'y':127.0214100,'trans':1,'food':2,'drink':1,'ent':1,'famous':1,'people':1,'trail':0,'att':0};
    dong['중림동'] = {'x':37.5547580,'y':126.9644990,'trans':2,'food':1,'drink':1,'ent':1,'famous':1,'people':2,'trail':1,'att':0};
// 종로구
    dong['효자동'] = {'x':37.5826280,'y':126.9720570,'trans':0,'food':1,'drink':1,'ent':1,'famous':1,'people':2,'trail':2,'att':4};
    dong['사직동'] = {'x':37.5761640,'y':126.9688060,'trans':1,'food':1,'drink':1,'ent':1,'famous':0,'people':1,'trail':2,'att':3};
    dong['삼청동'] = {'x':37.5848380,'y':126.9819130,'trans':1,'food':3,'drink':2,'ent':1,'famous':4,'people':4,'trail':4,'att':4};
    dong['부암동'] = {'x':37.5926710,'y':126.9643870,'trans':0,'food':1,'drink':1,'ent':1,'famous':3,'people':3,'trail':5,'att':2};
    dong['평창동'] = {'x':37.6053350,'y':126.9668580,'trans':0,'food':1,'drink':1,'ent':0,'famous':1,'people':1,'trail':5,'att':2};
    dong['무악동'] = {'x':37.5763670,'y':126.9572490,'trans':2,'food':2,'drink':1,'ent':1,'famous':1,'people':2,'trail':4,'att':1};
    dong['교남동'] = {'x':37.5718390,'y':126.9619710,'trans':2,'food':3,'drink':2,'ent':2,'famous':1,'people':2,'trail':0,'att':0};
    dong['가회동'] = {'x':37.5800060,'y':126.9846910,'trans':2,'food':3,'drink':3,'ent':3,'famous':3,'people':3,'trail':5,'att':5};
    //dong('종로1234') = {'x':37.5706460,'y':126.9889680,'trans':4,'food':4,'drink':4,'ent':4,'famous':5,'people':5,'trail':4,'att':5};
    //dong('Jongno56') = {'x':37.5747750,'y':127.0029810,'trans':3,'food':2,'drink':2,'ent':2,'famous':4,'people':4,'trail':4,'att':5};
    dong['이화동'] = {'x':37.5769230,'y':127.0043000,'trans':1,'food':2,'drink':1,'ent':1,'famous':2,'people':2,'trail':1,'att':2};
    dong['혜화동'] = {'x':37.5867550,'y':127.0003550,'trans':2,'food':3,'drink':3,'ent':3,'famous':4,'people':3,'trail':1,'att':3};
    dong['창신동'] = {'x':37.5750910,'y':127.0121580,'trans':3,'food':3,'drink':2,'ent':2,'famous':2,'people':2,'trail':2,'att':2};
    dong['숭인동'] = {'x':37.5747060,'y':127.0186420,'trans':3,'food':3,'drink':3,'ent':2,'famous':2,'people':3,'trail':3,'att':3};
// 용산구
    dong['후암동'] = {'x':37.5498920,'y':126.9814210,'trans':2,'food':2,'drink':2,'ent':2,'famous':1,'people':2,'trail':3,'att':3};
    dong['남영동'] = {'x':37.5455660,'y':126.9744150,'trans':3,'food':4,'drink':3,'ent':3,'famous':2,'people':3,'trail':3,'att':2};
    dong['청파동'] = {'x':37.5435100,'y':126.9696100,'trans':4,'food':3,'drink':3,'ent':3,'famous':2,'people':3,'trail':3,'att':2};
    dong['효창동'] = {'x':37.5417320,'y':126.9613050,'trans':3,'food':2,'drink':2,'ent':2,'famous':3,'people':2,'trail':4,'att':3};
    dong['용문동'] = {'x':37.5383430,'y':126.9585000,'trans':3,'food':2,'drink':2,'ent':2,'famous':1,'people':2,'trail':0,'att':0};
    dong['한강로동'] = {'x':37.5290620,'y':126.9694880,'trans':4,'food':3,'drink':2,'ent':2,'famous':3,'people':4,'trail':2,'att':3};
    dong['이촌동'] = {'x':37.5161220,'y':126.9660700,'trans':3,'food':3,'drink':3,'ent':2,'famous':2,'people':3,'trail':5,'att':2};
    dong['이태원동'] = {'x':37.5400460,'y':126.9921020,'trans':2,'food':5,'drink':5,'ent':3,'famous':5,'people':4,'trail':3,'att':4};
    dong['한남동'] = {'x':37.5368390,'y':127.0049990,'trans':2,'food':3,'drink':3,'ent':2,'famous':3,'people':3,'trail':4,'att':3};
    dong['서빙고동'] = {'x':37.5204020,'y':126.9945800,'trans':2,'food':1,'drink':1,'ent':1,'famous':1,'people':2,'trail':4,'att':0};
    dong['보광동'] = {'x':37.5265040,'y':127.0011920,'trans':0,'food':2,'drink':2,'ent':1,'famous':1,'people':1,'trail':4,'att':2};
    dong['원효로'] = {'x':37.5342600,'y':126.9515840,'trans':3,'food':3,'drink':2,'ent':2,'famous':3,'people':3,'trail':4,'att':0};
// 강남구
    dong['신사동'] = {'x':37.5241240,'y':127.0228830,'trans':4,'food':5,'drink':5,'ent':4,'famous':5,'people':4,'trail':1,'att':0};
    dong['압구정동'] = {'x':37.5316840,'y':127.0302930,'trans':4,'food':5,'drink':5,'ent':4,'famous':4,'people':4,'trail':5,'att':0};
    dong['청담동'] = {'x':37.5232000,'y':127.0486650,'trans':3,'food':4,'drink':4,'ent':4,'famous':4,'people':4,'trail':1,'att':0};
    dong['논현동'] = {'x':37.5135300,'y':127.0315340,'trans':4,'food':4,'drink':4,'ent':4,'famous':4,'people':4,'trail':1,'att':0};
    dong['삼성동'] = {'x':37.5139850,'y':127.0565210,'trans':4,'food':4,'drink':4,'ent':2,'famous':5,'people':4,'trail':2,'att':2};
    dong['역삼동'] = {'x':37.4999070,'y':127.0373930,'trans':3,'food':5,'drink':5,'ent':5,'famous':5,'people':5,'trail':1,'att':0};
    dong['대치동'] = {'x':37.4994910,'y':127.0610530,'trans':3,'food':3,'drink':3,'ent':2,'famous':3,'people':3,'trail':3,'att':0};
    dong['도곡동'] = {'x':37.4898430,'y':127.0438140,'trans':4,'food':3,'drink':3,'ent':2,'famous':3,'people':3,'trail':3,'att':0};
    dong['개포동'] = {'x':37.4789640,'y':127.0609280,'trans':2,'food':3,'drink':2,'ent':1,'famous':2,'people':2,'trail':3,'att':0};
    dong['일원동'] = {'x':37.4810130,'y':127.0801090,'trans':2,'food':2,'drink':2,'ent':1,'famous':1,'people':1,'trail':3,'att':0};
    dong['수서동'] = {'x':37.4864400,'y':127.0961270,'trans':3,'food':2,'drink':3,'ent':1,'famous':3,'people':3,'trail':3,'att':0};
    dong['세곡동'] = {'x':37.4692710,'y':127.1073200,'trans':1,'food':1,'drink':1,'ent':1,'famous':1,'people':1,'trail':2,'att':0};
// 송파구
    dong['풍납동'] = {'x':37.5327380,'y':127.1134890,'trans':2,'food':2,'drink':2,'ent':2,'famous':2,'people':2,'trail':4,'att':3};
    dong['거여동'] = {'x':37.4900430,'y':127.1462060,'trans':2,'food':2,'drink':2,'ent':2,'famous':1,'people':2,'trail':3,'att':1};
    dong['마천동'] = {'x':37.4976490,'y':127.1530170,'trans':2,'food':4,'drink':3,'ent':3,'famous':3,'people':3,'trail':3,'att':3};
    dong['방이동'] = {'x':37.5164030,'y':127.1215350,'trans':3,'food':4,'drink':4,'ent':3,'famous':4,'people':3,'trail':5,'att':4};
    dong['오금동'] = {'x':37.5037160,'y':127.1333750,'trans':3,'food':3,'drink':2,'ent':2,'famous':2,'people':2,'trail':2,'att':1};
    dong['송파동'] = {'x':37.5057651,'y':127.1094973,'trans':2,'food':2,'drink':2,'ent':1,'famous':2,'people':2,'trail':3,'att':2};
    dong['석촌동'] = {'x':37.5030770,'y':127.1017920,'trans':2,'food':2,'drink':2,'ent':1,'famous':2,'people':3,'trail':3,'att':3};
    dong['삼전동'] = {'x':37.5027950,'y':127.0925160,'trans':1,'food':3,'drink':3,'ent':2,'famous':2,'people':1,'trail':3,'att':1};
    dong['가락동'] = {'x':37.4962865,'y':127.1220975, 'trans':4,'food':4,'drink':3,'ent':2,'famous':4,'people':3,'trail':3,'att':4};
    dong['문정동'] = {'x':37.4851330,'y':127.1238460,'trans':3,'food':3,'drink':3,'ent':2,'famous':3,'people':3,'trail':3,'att':3};
    dong['장지동'] = {'x':37.4869640,'y':127.1322620,'trans':3,'food':1,'drink':1,'ent':1,'famous':1,'people':1,'trail':4,'att':0};
    dong['잠실동'] = {'x':37.5128990,'y':127.0829930,'trans':3,'food':4,'drink':4,'ent':4,'famous':5,'people':5,'trail':4,'att':5};
    dong['신천동'] = {'x':37.5116240,'y':127.0855850,'trans':3,'food':3,'drink':3,'ent':2,'famous':4,'people':5,'trail':5,'att':3};
// 영등포구
    dong['영등포동'] = {'x':37.5132560,'y':126.9057790,'trans':2,'food':2,'drink':2,'ent':1,'famous':2,'people':2,'trail':2,'att':0};
    dong['여의도'] = {'x':37.5175400,'y':126.9345310,'trans':4,'food':3,'drink':3,'ent':2,'famous':4,'people':3,'trail':5,'att':4};
    dong['당산동'] = {'x':37.5391120,'y':126.9033940,'trans':3,'food':3,'drink':3,'ent':3,'famous':2,'people':3,'trail':5,'att':0};
    dong['도림동'] = {'x':37.5094020,'y':126.8960070,'trans':1,'food':2,'drink':2,'ent':2,'famous':1,'people':2,'trail':0,'att':0};
    dong['문래동'] = {'x':37.5169840,'y':126.8993950,'trans':2,'food':2,'drink':1,'ent':1,'famous':2,'people':2,'trail':3,'att':0};
    dong['양평동'] = {'x':37.5390830,'y':126.8883520,'trans':3,'food':3,'drink':3,'ent':3,'famous':2,'people':3,'trail':4,'att':0};
    dong['신길동'] = {'x':37.5062490,'y':126.9139520,'trans':4,'food':3,'drink':3,'ent':2,'famous':2,'people':3,'trail':3,'att':1};
    dong['대림동'] = {'x':37.4955090,'y':126.8994380,'trans':3,'food':3,'drink':2,'ent':2,'famous':2,'people':2,'trail':1,'att':0};
// 동작구
    dong['노량진동'] = {'x':37.5110030,'y':126.9416330,'trans':3,'food':4,'drink':4,'ent':3,'famous':4,'people':4,'trail':3,'att':1};
    dong['상도동'] = {'x':37.4989900,'y':126.9377190,'trans':2,'food':4,'drink':3,'ent':3,'famous':2,'people':3,'trail':3,'att':2};
    dong['흑석동'] = {'x':37.5094860,'y':126.9605290,'trans':2,'food':3,'drink':3,'ent':3,'famous':3,'people':3,'trail':3,'att':2};
    dong['사당동'] = {'x':37.4862550,'y':126.9733320,'trans':4,'food':4,'drink':3,'ent':3,'famous':4,'people':4,'trail':3,'att':2};
    dong['신대방동'] = {'x':37.4888811,'y':126.9092909,'trans':3,'food':2,'drink':2,'ent':2,'famous':3,'people':3,'trail':4,'att':2};
    dong['대방동'] = {'x':37.5080960,'y':126.9262540,'trans':4,'food':2,'drink':2,'ent':2,'famous':1,'people':2,'trail':3,'att':2};
// 서초구
    dong['서초동'] = {'x':37.4876870,'y':127.0174270,'trans':3,'food':3,'drink':3,'ent':2,'famous':4,'people':4,'trail':2,'att':5};
    dong['잠원동'] = {'x':37.5148470,'y':127.0143280,'trans':4,'food':4,'drink':4,'ent':3,'famous':4,'people':4,'trail':5,'att':1};
    dong['반포동'] = {'x':37.5031830,'y':127.0079170,'trans':4,'food':4,'drink':4,'ent':3,'famous':5,'people':5,'trail':3,'att':2};
    dong['방배동'] = {'x':37.4799350,'y':126.9934600,'trans':4,'food':3,'drink':4,'ent':3,'famous':2,'people':3,'trail':2,'att':1};
    dong['양재동'] = {'x':37.4731980,'y':127.0381700,'trans':2,'food':4,'drink':3,'ent':2,'famous':2,'people':3,'trail':5,'att':2};
/*    dong['내곡동'] = {'x':37.4617710,'y':127.0511600,'trans':0,'food':0,'drink'0,'ent':0,'famous':0,'people':0,'trail':4,'att':0};
// 양천구
    dong['목동'] = {'x':37.5370190,'y':126.8735300,'trans':2,'food':3,'drink'3,'ent':3,'famous':3,'people':3,'trail':4,'att':2};
    dong['신월동'] = {'x':37.5199810,'y':126.8365550,'trans':1,'food':1,'drink'1,'ent':1,'famous':1,'people':1,'trail':2,'att':1};
    dong['신정동'] = {'x':37.5164950,'y':126.8658973,'trans':2,'food':2,'drink'1,'ent':2,'famous':1,'people':1,'trail':3,'att':1};
// 구로구
    dong['신도림동'] = {'x':37.5077350,'y':126.8805910,'trans':2,'food':4,'drink':3,'ent':3,'famous':2,'people':3,'trail':3,'att':2};
    dong['구로동'] = {'x':37.4951850,'y':126.8820640,'trans':4,'food':3,'drink':3,'ent':3,'famous':4,'people':3,'trail':4,'att':3};
    dong['가리봉동'] = {'x':37.4832690,'y':126.8868410,'trans':1,'food':1,'drink':1,'ent':1,'famous':1,'people':1,'trail':0,'att':1};
    dong['고척동'] = {'x':37.5011410,'y':126.8625000,'trans':1,'food':2,'drink':1,'ent':1,'famous':1,'people':1,'trail':3,'att':1};
    dong['개봉동'] = {'x':37.4888720,'y':126.8557490,'trans':1,'food':2,'drink':2,'ent':1,'famous':1,'people':1,'trail':4,'att':1};
    dong['오류동'] = {'x':37.4901260,'y':126.8385250,'trans':3,'food':3,'drink':3,'ent':2,'famous':2,'people':3,'trail':3,'att':1};
// 금천구
*/