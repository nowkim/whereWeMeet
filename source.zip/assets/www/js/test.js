
{
  "messages" : {
    "-K2ib4H77rj0LYewF7dP" : {
      "text" : "Hello",
      "name" : "anonymous"
    },
    "-K2ib5JHRbbL0NrztUfO" : {
      "text" : "How are you",
      "name" : "anonymous"
    },
    "-K2ib62mjHh34CAUbide" : {
      "text" : "I am fine",
      "name" : "anonymous"
    }
  }
}