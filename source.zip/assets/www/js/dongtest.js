    var dong = new Array();
// 마포구
    dong['공덕동'] = {'x':126.9599990,'y':37.5501480,'trans':5,'food':3,'drink':3,'ent':2,'famous':3,'people':3, 'trail':2,'att':0};
    dong['연남동'] = {'x':126.9223680,'y':37.5638000,'trans':3,'food':5,'drink':3,'ent':1,'famous':5,'people':4, 'trail':5,'att':0};
    dong['서교동'] = {'x':126.9220860,'y':37.5562990,'trans':5,'food':5,'drink':5,'ent':5,'famous':5,'people':5,'trail':2,'att':3};
    dong['대흥동'] = {'x':126.9426400,'y':37.5559520,'trans':3,'food':2,'drink':2,'ent':1,'famous':1,'people':3,'trail':3,'att':0};
    dong['신수동'] = {'x':126.9345580,'y':37.5468420,'trans':3,'food':1,'drink':1,'ent':1,'famous':0,'people':1,'trail':1,'att':0};
    dong['서강동'] = {'x':126.9324190,'y':37.5480090,'trans':3,'food':4,'drink':3,'ent':1,'famous':3,'people':3,'trail':3,'att':0};
// 서대문구
    dong['신촌동'] = {'x':126.9435840,'y':37.5594790,'trans':4,'food':4,'drink':4,'ent':4,'famous':4,'people':4,'trail':1,'att':3};
    dong['연희동'] = {'x':126.9352540,'y':37.5738940,'trans':2,'food':4,'drink':2,'ent':1,'famous':3,'people':3, 'trail':3,'att':0};