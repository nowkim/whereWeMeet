'use strict'

/**
 * Initialize Firebase
 * TODO: Replace with your project's customized code snippet
 */

<script src="https://www.gstatic.com/firebasejs/3.6.1/firebase.js"></script>
<script>

</script>

/**
 * The main app module
 *
 * @type {angular.Module}
 */
