
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyClCi-zE3_vmkCyO-MycdkJ6gErcgrMPAg",
    authDomain: "whereshouldwego-7557b.firebaseapp.com",
    databaseURL: "https://whereshouldwego-7557b.firebaseio.com",
    storageBucket: "whereshouldwego-7557b.appspot.com",
    messagingSenderId: "1010973572679"
  };
  firebase.initializeApp(config);